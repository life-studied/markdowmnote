#pragma once
#include <utility>
#include <mutex>
#include <shared_mutex>
#include <condition_variable>

#include "debug.h"

constexpr int disk_size = 20;
constexpr int buffer_size = disk_size / 5;

inline static void check(char data, int idx) {
	printf("check data:\tdisk idx: %d,\tdata: %c\n", idx, data);
}

class BufferPool {

	using block_type = char[20];
public:
	BufferPool() {
		for (auto i = 0; i < buffer_size; ++i)
			unused_buffer_pool.push_back(i);
	}

	void Write(int disk_idx, char data) {
		int buffer_idx;
		{
			std::shared_lock<std::shared_mutex> lock(disk_map_mutex);
			buffer_idx = disk_map[disk_idx];
		}
		
		auto idx = disk_block_write_idx[disk_idx].fetch_add(1);
		pool[buffer_idx][idx] = data;
#ifdef DEBUG_INFO
		std::printf("write success:\tthread:%d,\tdisk:%d, idx:%d, data:%c \n", std::this_thread::get_id(), disk_idx, idx, data);
#endif
	}

	std::mutex& GetLock(int i) {
		return mtxs[i];
	}

	int GetBufferIdx(int disk_idx) {
		std::shared_lock<std::shared_mutex> lock(disk_map_mutex);
		return disk_map[disk_idx];
	}

	void Replace(int replaced_disk_idx, int disk_idx) {
#ifdef DEBUG_INFO
		std::printf("buffer replace:\tthread:%d,\t%d replace %d, size:%d\n", std::this_thread::get_id(), disk_idx, replaced_disk_idx, disk_map.size());
#endif
		int replaced_buffer_idx;
		{
			std::shared_lock<std::shared_mutex> lock(disk_map_mutex);
			replaced_buffer_idx = disk_map[replaced_disk_idx];
		}
		// ˢ�� ��ҳ
		copy_from_buffer_to_disk(replaced_buffer_idx, replaced_disk_idx);
		std::atomic_thread_fence(std::memory_order::acq_rel);
		copy_from_disk_to_buffer(disk_idx, replaced_buffer_idx);

		// ���� disk_map
		{
			std::unique_lock<std::shared_mutex> lock(disk_map_mutex);
			remove_from_disk_map(replaced_disk_idx);
			save_into_disk_map(disk_idx, replaced_buffer_idx);
		}
	}

	void Load(int disk_idx) {
		auto free_buffer = get_buffer_free();
		load_disk_to_free_buffer(disk_idx, free_buffer.value());
	}

	void CheckLoad(int disk_idx) {
		while (true) {
			// ���disk�Ƿ�װ�سɹ�
			{
				std::shared_lock<std::shared_mutex> lock(disk_map_mutex);
				auto it = disk_map.find(disk_idx);
				if (it != disk_map.end()) {
					return;
				}
			}

			// û���ҵ�buffer��˵�����ڵȴ������߳̽���replace
#ifdef DEBUG_INFO
			std::printf("wait replace:\tthread:%d,\tdisk_id:%d\n", std::this_thread::get_id(), disk_idx);
#endif
			std::this_thread::yield();
			continue;
			
		}
	}

	void FlushAll() {
		for (auto& i : disk_map) {
			auto buffer_idx = i.second;
			auto disk_idx = i.first;
			copy_from_buffer_to_disk(buffer_idx, disk_idx);
		}
	}

	void Print() {
		for (auto& i : disk) {
			for (auto& j : i) {
				std::cout << j;
			}
			std::cout << std::endl;
		}
	}
private:
	std::optional<int> get_buffer_free() {
		std::optional<int> ret;
		std::lock_guard<std::mutex> lock(unused_buffer_pool_mutex);
		if (unused_buffer_pool.empty()) {
			return std::nullopt;
		}

		ret = unused_buffer_pool.front();
		unused_buffer_pool.pop_front();

		return ret;
	}

	void load_disk_to_free_buffer(int disk_idx, int buffer_idx) {
#ifdef DEBUG_INFO
		std::printf("buffer load:\tthread:%d,\t%d load into %d,\tsize:%d\n", std::this_thread::get_id(), disk_idx, buffer_idx, disk_map.size());
#endif
		copy_from_disk_to_buffer(disk_idx, buffer_idx);
		std::unique_lock<std::shared_mutex> lock(disk_map_mutex);
		save_into_disk_map(disk_idx, buffer_idx);
	}

	void copy_from_disk_to_buffer(int disk_idx, int buffer_idx) {
		memcpy(pool[buffer_idx], disk[disk_idx], sizeof(block_type));
	}

	void copy_from_buffer_to_disk(int buffer_idx, int disk_idx) {
		memcpy(disk[disk_idx], pool[buffer_idx], sizeof(block_type));
	}

	void save_into_disk_map(int disk_idx, int buffer_idx) {
		disk_map[disk_idx] = buffer_idx;
	}

	void remove_from_disk_map(int old_disk_idx) {
		disk_map.erase(old_disk_idx);
	}
private:
	// �����
	std::array<block_type, buffer_size> pool = {};
	// ÿ��disk��Ŀǰд��������
	std::array<std::atomic<int>, disk_size> disk_block_write_idx = {};
	// ÿ����������
	std::array<std::mutex, buffer_size> mtxs;
	// ģ�����
	std::array<block_type, disk_size> disk = {};
	// ���ٲ��ң�disk idx �������ڵ� buffer idx
	std::unordered_map<int, int> disk_map;
	// disk_map ����
	std::shared_mutex disk_map_mutex;
	// δ��ʹ�õ�buffer
	std::list<int> unused_buffer_pool;
	// unused_buffer_pool ����
	std::mutex unused_buffer_pool_mutex;

};