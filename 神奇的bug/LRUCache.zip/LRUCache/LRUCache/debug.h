#pragma once
//#define DEBUG_INFO

#ifdef DEBUG_INFO
#define debug(fmt, ...) \
printf("threadid:%d\t"##fmt, std::this_thread::get_id(), __VA_ARGS__)
#else
#define debug(fmt, ...)
#endif