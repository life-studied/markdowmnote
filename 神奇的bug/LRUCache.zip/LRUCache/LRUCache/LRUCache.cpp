﻿#include <iostream>
#include <array>
#include <random>
#include <cassert>

#include "LRUCache.h"
#include "BufferPool.h"


int main()
{
	BufferPool pool;

	LRU<int> l(buffer_size);

	std::array<std::thread, disk_size> thread_pool;

	
	for (int i = 0; i < disk_size; ++i) {
		thread_pool[i] = std::thread([&, i = i]() {
			std::random_device rd;
			std::mt19937 eng(rd());
			std::uniform_int_distribution<int> gen(0,19);
			// k代表当前正在读写的磁盘id
			int k = gen(eng);
			int cnt = 0; 
			// 每个线程都要经过所有20个磁盘块的读写考验
			for (; cnt < 20; ) {
				auto [success, direct_load, replaced_disk_idx] = l.PutAndPin(k);

				// 没有能用的buffer，重试
				if (!success) {
					std::this_thread::yield();
					continue;
				}
				
				if (direct_load) {
					// 不在pool里，但有空闲buffer，直接加载
					pool.Load(k);
				}
				else if (replaced_disk_idx) {
					// 需要替换buffer的方式，加载
					pool.Replace(replaced_disk_idx.value(), k);
				}
				else {
					// 策略已经放入buffer pool里，但不一定立即生效
					pool.CheckLoad(k);
				}

				int buffer_idx = pool.GetBufferIdx(k);

				// 写入数据
				char data = k % 4 + '1';
				pool.Write(k, data);

				std::atomic_thread_fence(std::memory_order::acq_rel);

				l.UnPin(k);
				++k;
				++cnt;
				k %= 20;
			}
			});
	}

	for (int i = 0; i < disk_size; ++i) {
		if(thread_pool[i].joinable())
			thread_pool[i].join();
	}

	pool.FlushAll();
	pool.Print();

}